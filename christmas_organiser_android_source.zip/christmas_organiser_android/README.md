# 🎄 Christmas Organiser — Android app

A fully offline Android Christmas planning app, with evergreen-and-gold Christmas styling, falling snow, animated sparkle **Edit** buttons and cosy festive forms. Created for a personal Android phone.

## Features

- **Christmas home screen:** Days until Christmas, live progress cards and upcoming events.
- **Christmas cards:** Names, addresses, notes, editable categories (Family, Friends, Neighbours, Work, Other), plus *Written* and *Sent* checkboxes.
- **Christmas calendar:** Month view, editable dated events, times, locations and notes, with red dots showing plans.
- **Present lists:** Recipient, gift idea, price, notes, custom categories, *Bought* and *Wrapped* checkboxes, adjustable overall budget and planned-versus-spent totals.
- **Elf on the Shelf:** 12 built-in setup ideas, plus adding, editing, deleting, searching and marking ideas as tried.
- **Food and drinks:** Separate shopping lists with quantities, notes, and *Bought* checkboxes.
- **Editing effects:** Gold sparkles burst when you tap a festive gold **Edit** button; animated pencil and snowfall.
- **Back up / restore:** Share a JSON backup via Android's share sheet. Restore by pasting a previously exported JSON backup.
- **Offline-first:** Everything works without an account, mobile data or internet permissions.

## Getting an installable APK from GitHub

1. Upload **all** files and directories in this project to the **root** of your GitHub repository (including the hidden `.github` folder).
2. Go to your repository's **Actions** tab. Choose **Build Android APK** then **Run workflow** (or just push to `main` and the build starts automatically).
3. After the build succeeds, open its run, scroll to **Artifacts**, and download **christmas-organiser-apk**.
4. Open the downloaded ZIP; inside is **app-debug.apk**. Install it on your Samsung Android phone. Android may ask you to allow installation from your Files app.

The workflow uses Java 17, Android SDK 35 and Gradle 8.9. The debug APK is signed with a development key for personal use, **not** for Google Play distribution. Builds generated at different times can use different debug signing keys, so when updating the app keep the same signing key if you want to preserve app data.

## Build in Android Studio

Open the project folder in Android Studio. It is a standard Java Android Gradle project using Android Gradle Plugin `8.7.3`, compile SDK `35`, minimum SDK `26`, and target SDK `34`. Gradle can be installed by Android Studio, or use Gradle 8.9 and run `gradle assembleDebug`.

## Project layout

- `app/src/main/assets/index.html` — app structure
- `app/src/main/assets/styles.css` — Christmas design and edit-button animations
- `app/src/main/assets/app.js` — lists, search, categories, calendar, editing, backup and state
- `app/src/main/java/uk/co/christmas/organiser/MainActivity.java` — Android WebView, local native preferences and Android sharing
- `.github/workflows/android.yml` — automatic GitHub Android APK build

## Privacy and saved data

Data is saved in the application's private Android `SharedPreferences` through a JavaScript-to-Android bridge. When run as a web preview, the interface falls back to the browser's `localStorage`. All data stays on the device unless **you choose** to share an export. Clearing app storage or uninstalling can lose saved lists, so make a backup first. This app has no internet permission, ads or trackers.
