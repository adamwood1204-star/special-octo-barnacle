/* Christmas Organiser - fully offline, no external services or dependencies. */
'use strict';

const STORAGE_KEY = 'christmas-organiser-v2';
const DEFAULT_ELF_IDEAS = [
  ['Marshmallow snow angels', 'Lay the elf in a tray of mini marshmallows and make little snow-angel shapes.'],
  ['Candy cane treasure hunt', 'Hide candy canes around the room and leave a clue with the elf.'],
  ['Elf movie night', 'Set the elf up with popcorn and a tiny paper cinema ticket.'],
  ['Toilet-roll snowman', 'Stack three loo rolls and draw a snowman face on the top one.'],
  ['The frozen elf', 'Sit the elf in a sealed clear container with a sign saying “Brrr!”.'],
  ['Mini breakfast chef', 'Put a little apron on the elf beside the cereal bowls.'],
  ['Wrapped-up TV remote', 'Gift-wrap the TV remote and let the elf take the blame.'],
  ['A note from Santa', 'Leave a short handwritten letter praising a kind deed.'],
  ['Elf fishing trip', 'Make a paper fishing rod and fish for crackers in a bowl.'],
  ['Paper snowflake station', 'Leave paper snowflakes and scissors ready for a craft afternoon.'],
  ['Silly family portraits', 'Let the elf add removable paper hats to framed photos.'],
  ['Christmas Eve goodbye', 'Leave the elf with a thank-you note and a big goodbye wave.']
];
const x = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const id = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);
const todayISO = () => { const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const now = new Date();
const defaultState = () => ({
  schema:2,
  cards:[], events:[], gifts:[],
  elves:DEFAULT_ELF_IDEAS.map(([title,notes])=>({id:id(),title,notes,done:false})),
  shopping:[],
  categories:{cards:['Family','Friends','Neighbours','Work','Other'],gifts:['Family','Friends','Children','Work','Other']},
  giftBudget:500
});
function normalise(input){
  const fallback=defaultState();
  if(!input || typeof input!=='object' || Array.isArray(input)) return fallback;
  for(const k of ['cards','events','gifts','elves','shopping']) if(Array.isArray(input[k]))fallback[k]=input[k].filter(z=>z&&typeof z==='object').map(z=>({...z,id:String(z.id || id())}));
  for(const k of ['cards','gifts']) if(Array.isArray(input.categories?.[k]) && input.categories[k].some(v=>typeof v==='string'&&v.trim()))fallback.categories[k]=Array.from(new Set(input.categories[k].filter(v=>typeof v==='string'&&v.trim()).map(v=>v.trim().slice(0,45))));
  if(input.giftBudget!==undefined && input.giftBudget!==null && Number.isFinite(Number(input.giftBudget)))fallback.giftBudget=Math.max(0,Math.min(1000000,Number(input.giftBudget)));
  return fallback;
}
function readStorage(){
  try {const saved=(window.AndroidStore && typeof AndroidStore.read==='function')?AndroidStore.read():localStorage.getItem(STORAGE_KEY); if(saved)return normalise(JSON.parse(saved));}catch(e){console.warn('Could not load data',e)}
  return defaultState();
}
let data=readStorage();
let ui={page:'home',cardsFilter:'All',giftsFilter:'All',elfFilter:'All',shopGroup:'Food',calendarMonth:`${now.getFullYear()}-12`,selectedDate:`${now.getFullYear()}-12-25`,search:{cards:'',gifts:'',elf:'',shopping:''}};
let toastTimeout;
function persist(){
  try {const value=JSON.stringify(data); if(window.AndroidStore&&typeof AndroidStore.write==='function') AndroidStore.write(value);else localStorage.setItem(STORAGE_KEY,value);}catch(e){console.error('Save problem:',e);toast('Could not save on this device');}
}
function toast(msg){const node=document.getElementById('toast');node.textContent=msg;node.classList.add('show');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>node.classList.remove('show'),2400)}
const GBP = v => new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(Number(v)||0);
function dateLabel(value,opts={day:'numeric',month:'short',year:'numeric'}) {if(!/^\d{4}-\d{2}-\d{2}$/.test(String(value)))return value||'';const [y,m,d]=value.split('-').map(Number);return new Date(y,m-1,d).toLocaleDateString('en-GB',opts)}
function nextChristmas(){const today=new Date();let y=today.getFullYear();if(new Date(y,today.getMonth(),today.getDate())>new Date(y,11,25))y++;return new Date(y,11,25)}
function daysToChristmas(){const today=new Date();return Math.max(0,Math.round((nextChristmas()-new Date(today.getFullYear(),today.getMonth(),today.getDate()))/86400000))}
function stat(emoji,num,description){return `<div class="stat"><span class="stat-icon">${emoji}</span><strong>${x(num)}</strong><span>${x(description)}</span></div>`}
function header(eyebrow,title,desc,emoji){return `<div class="page-header"><span class="eyebrow">${eyebrow}</span><div class="title-row"><div><h1 class="page-title">${title}</h1><p class="page-subtitle">${desc}</p></div><span class="badge-emoji" aria-hidden="true">${emoji}</span></div></div>`}
function empty(emoji,title,desc,add,type){return `<div class="empty"><div class="empty-icon">${emoji}</div><h3>${title}</h3><p>${desc}</p>${add?`<button class="btn primary" data-new="${type}">✦ ${add}</button>`:''}</div>`}
function editButton(type,key){return `<button class="edit-btn" data-edit="${type}" data-id="${x(key)}" aria-label="Edit item"><span class="pencil">✎</span> Edit</button>`}
function actionRow(type,key,checks){return `<div class="item-actions"><div class="left">${checks}</div><div class="button-row">${editButton(type,key)}<button class="small-link" data-delete="${type}" data-id="${x(key)}" aria-label="Delete item">Delete</button></div></div>`}
function checkbox(type,key,field,label,checked){return `<label class="check-label"><input type="checkbox" data-toggle="${type}" data-id="${x(key)}" data-field="${field}" ${checked?'checked':''}> ${label}</label>`}
function chips(items,selected,kind){return `<div class="filterbar" aria-label="Filter"><button class="chip ${selected==='All'?'selected':''}" data-filter="${kind}" data-value="All">All</button>${items.map(z=>`<button class="chip ${selected===z?'selected':''}" data-filter="${kind}" data-value="${x(z)}">${x(z)}</button>`).join('')}</div>`}
function searchField(kind,placeholder){return `<input class="search-field" data-search="${kind}" value="${x(ui.search[kind])}" placeholder="${x(placeholder)}" aria-label="Search ${kind}">`}
function getCounts(){return {cards:data.cards.filter(z=>z.sent).length,gifts:data.gifts.filter(z=>z.bought).length,events:data.events.length,elf:data.elves.filter(z=>z.done).length,shopping:data.shopping.filter(z=>z.bought).length}}
function home(){
 const s=getCounts();const upcoming=data.events.filter(z=>z.date>=todayISO()).sort((a,b)=>(a.date+' '+(a.time||'')).localeCompare(b.date+' '+(b.time||''))).slice(0,3);
 return `<section class="hero"><span class="kicker">✦ Your festive planner ✦</span><h1>Make Christmas <em>magical.</em></h1><p>All your merry little plans in one cosy place.</p><div class="hero-count"><span>❄</span><strong>${daysToChristmas()}</strong><span>${daysToChristmas()===1?'day':'days'} until Christmas</span></div><span class="hero-tree" aria-hidden="true">🎄</span></section>
 <div class="welcome"><div class="soft">Your Christmas, organised with love</div><h2>A little festive progress ✨</h2></div>
 <div class="stats">${stat('💌',`${s.cards}/${data.cards.length}`,'Cards sent')}${stat('🎁',`${s.gifts}/${data.gifts.length}`,'Presents bought')}${stat('📅',s.events,'Plans made')}</div>
 <div class="section-head"><h2>Your Christmas checklist</h2><span class="tiny">Tap to plan</span></div>
 <div class="quick-grid">
 ${quick('cards','💌','Christmas cards',`${data.cards.length} people on your list`)}
 ${quick('calendar','📅','Christmas calendar',`${s.events} festive plans`)}
 ${quick('presents','🎁','Present lists',`${data.gifts.length} gifts planned`)}
 ${quick('elf','🧝','Elf on the Shelf',`${s.elf} of ${data.elves.length} ideas tried`)}
 ${quick('shopping','🍪','Food & drinks',`${data.shopping.length-s.shopping} left to buy`)}
 ${quick('settings','✨','Make it yours','Back up & personalise')}
 </div>
 <div class="section-head"><h2>Coming up</h2><a href="#calendar" data-go="calendar">See calendar ›</a></div>
 ${upcoming.length?upcoming.map(z=>`<div class="item"><div class="item-top"><span class="item-emoji">📅</span><div class="item-content"><div class="item-title">${x(z.title)}</div><div class="item-sub">${x(dateLabel(z.date))}${z.time?' · '+x(z.time):''}</div></div>${editButton('event',z.id)}</div></div>`).join(''):empty('⭐','Your calendar is waiting','Add Christmas parties, special days and family plans.','Add a date','event')}
 <div class="tip-card"><strong>🎅 A little Christmas magic</strong><p>You can edit every list, add your own categories and tick things off as you go. Everything saves automatically on this phone.</p></div>
 <div class="footer-note">Made with festive cheer ❄ · Works offline</div>`;
}
function quick(page,emoji,title,subtitle){return `<button class="quick-card" data-go="${page}"><div class="quick-icon">${emoji}</div><div class="quick-name">${title}</div><div class="quick-detail">${x(subtitle)}</div></button>`}
function cards(){
 const all=data.cards;const filtered=all.filter(z=>(ui.cardsFilter==='All'||z.category===ui.cardsFilter)&&[z.name,z.address,z.notes,z.category].some(v=>String(v||'').toLowerCase().includes(ui.search.cards.toLowerCase())));
 return header('The nice list','Christmas cards','Keep track of everyone you want to send a little joy to.','💌')+
 `<div class="stats">${stat('💌',all.length,'People')}${stat('✍️',all.filter(z=>z.written).length,'Written')}${stat('📮',all.filter(z=>z.sent).length,'Sent')}</div>
 <div class="toolbar"><button class="btn primary" data-new="card">＋ Add person</button><button class="btn cream" data-categories="cards">✎ Edit categories ✨</button></div>
 ${searchField('cards','Search names or addresses…')}${chips(data.categories.cards,ui.cardsFilter,'cards')}
 <div class="list-title">Card list <span>${filtered.length} shown</span></div>
 ${filtered.length?filtered.map(z=>`<article class="item ${z.sent?'done':''}"><div class="item-top"><span class="item-emoji">${z.sent?'📮':'💌'}</span><div class="item-content"><div class="item-title">${x(z.name)}</div>${z.address?`<p class="item-sub">${x(z.address)}</p>`:''}${z.notes?`<p class="item-sub">${x(z.notes)}</p>`:''}<div class="item-tags"><span class="tag">${x(z.category||'Other')}</span>${z.sent?'<span class="tag gold">Sent 🎉</span>':''}</div></div></div>${actionRow('card',z.id,checkbox('card',z.id,'written','Written',z.written)+checkbox('card',z.id,'sent','Sent',z.sent))}</article>`).join(''):empty('💌',all.length?'No matching cards':'Nobody on the list yet',all.length?'Try a different category or name.':'Add friends and family and keep track of their cards.',all.length?'':'Add first person','card')}`;
}
function calendar(){
 const [year,month]=ui.calendarMonth.split('-').map(Number);const first=new Date(year,month-1,1);const offset=(first.getDay()+6)%7;const gridStart=new Date(year,month-1,1-offset);
 const currentToday=todayISO();const cells=[];
 for(let n=0;n<42;n++){
  const d=new Date(gridStart);d.setDate(d.getDate()+n);
  const ymd=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const hasEvents=data.events.some(e=>e.date===ymd);
  cells.push(`<button class="day ${d.getMonth()+1!==month?'off':''} ${ymd===currentToday?'today':''} ${ymd===ui.selectedDate?'selected':''}" data-day="${ymd}" aria-label="${x(dateLabel(ymd))}" aria-pressed="${ymd===ui.selectedDate}">${d.getDate()}${hasEvents?'<span class="dot"></span>':''}</button>`);
 }
 const chosen=data.events.filter(z=>z.date===ui.selectedDate).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
 const upcoming=data.events.filter(z=>z.date!==ui.selectedDate).sort((a,b)=>(a.date+' '+(a.time||'')).localeCompare(b.date+' '+(b.time||''))).slice(0,12);
 return header('Make a date','Christmas calendar','Parties, traditions, Christmas days and cosy nights in.','📅')+
 `<div class="toolbar"><button class="btn primary" data-new="event">＋ Add event</button><button class="btn secondary sm" data-today="true">Jump to today</button></div>
 <div class="calendar-panel"><div class="calendar-head"><button class="month-control" data-month="-1" aria-label="Previous month">‹</button><h3>${first.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</h3><button class="month-control" data-month="1" aria-label="Next month">›</button></div>
 <div class="calendar-grid">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(z=>`<div class="weekday">${z}</div>`).join('')}${cells.join('')}</div><div class="calendar-legend">● Red dots mean you have a plan that day</div></div>
 <div class="date-head"><span>✨ ${x(dateLabel(ui.selectedDate,{weekday:'long',day:'numeric',month:'long'}))}</span><button class="btn secondary sm" data-new="event">＋ Add</button></div>
 ${chosen.length?chosen.map(eventRow).join(''):empty('🗓️','Nothing planned for this day','Tap Add to put something special in the calendar.','Add a plan','event')}
 <div class="section-head"><h3>All other plans</h3><span class="tiny">${upcoming.length} shown</span></div>
 ${upcoming.length?upcoming.map(eventRow).join(''):'<div class="panel green"><span class="tiny">Your other events will show here once added.</span></div>'}`;
}
function eventRow(z){return `<article class="item"><div class="item-top"><span class="item-emoji">${z.emoji||'🎄'}</span><div class="item-content"><div class="item-title">${x(z.title)}</div><p class="item-sub">${x(dateLabel(z.date))} ${z.time?`<span class="time-pill">${x(z.time)}</span>`:''}</p>${z.location?`<p class="item-sub">📍 ${x(z.location)}</p>`:''}${z.notes?`<p class="item-sub">${x(z.notes)}</p>`:''}</div></div>${actionRow('event',z.id,'<span class="tiny">Special Christmas moment ✨</span>')}</article>`}
function presents(){
 const all=data.gifts;const total=all.reduce((a,z)=>a+(Number(z.price)||0),0);const spent=all.filter(z=>z.bought).reduce((a,z)=>a+(Number(z.price)||0),0);
 const filtered=all.filter(z=>(ui.giftsFilter==='All'||z.category===ui.giftsFilter)&&[z.recipient,z.gift,z.notes,z.category].some(v=>String(v||'').toLowerCase().includes(ui.search.gifts.toLowerCase())));
 const pct=data.giftBudget?Math.min(100,Math.round(total/data.giftBudget*100)):(total>0?100:0);
 return header('Santa’s workshop','Present lists','Keep gift ideas, budgets, shopping and wrapping in one spot.','🎁')+
 `<div class="panel gold"><div class="metric-line"><div><span class="eyebrow">Your present budget</span><div><b>${GBP(total)}</b> <small>planned / ${GBP(data.giftBudget)}</small></div></div><button class="edit-btn" data-budget="true"><span class="pencil">✎</span> Edit budget</button></div><div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div><div class="metric-line"><small>Spent on bought gifts: ${GBP(spent)}</small><small>${data.giftBudget?Math.round(total/data.giftBudget*100):0}% planned</small></div>${total>data.giftBudget?'<p class="warn" style="font-size:12px;margin:8px 0 0">🎅 Your planned gifts are over budget.</p>':''}</div>
 <div class="stats">${stat('🎁',all.length,'Gift ideas')}${stat('🛍️',all.filter(z=>z.bought).length,'Bought')}${stat('🎀',all.filter(z=>z.wrapped).length,'Wrapped')}</div>
 <div class="toolbar"><button class="btn primary" data-new="gift">＋ Add present</button><button class="btn cream" data-categories="gifts">✎ Edit categories ✨</button></div>
 ${searchField('gifts','Search gifts or recipients…')}${chips(data.categories.gifts,ui.giftsFilter,'gifts')}
 <div class="list-title">Your gifts <span>${filtered.length} shown</span></div>
 ${filtered.length?filtered.map(z=>`<article class="item ${z.wrapped?'done':''}"><div class="item-top"><span class="item-emoji">${z.wrapped?'🎀':'🎁'}</span><div class="item-content"><div class="item-title">${x(z.recipient)}</div><p class="item-sub">${x(z.gift)}</p>${z.notes?`<p class="item-sub">${x(z.notes)}</p>`:''}<div class="item-tags"><span class="tag">${x(z.category||'Other')}</span><span class="tag gold">${GBP(z.price)}</span>${z.wrapped?'<span class="tag">Wrapped ✓</span>':''}</div></div></div>${actionRow('gift',z.id,checkbox('gift',z.id,'bought','Bought',z.bought)+checkbox('gift',z.id,'wrapped','Wrapped',z.wrapped))}</article>`).join(''):empty('🎁',all.length?'No gifts found':'Your gift list is empty',all.length?'Try another category or search.':'Add the first present and keep all your ideas secret and organised.',all.length?'':'Add a gift','gift')}`;
}
function elf(){
 const all=data.elves;const filtered=all.filter(z=>(ui.elfFilter==='All'||(ui.elfFilter==='To try'&&!z.done)||(ui.elfFilter==='Done'&&z.done))&&[z.title,z.notes].some(v=>String(v||'').toLowerCase().includes(ui.search.elf.toLowerCase())));
 return header('North Pole mischief','Elf on the Shelf','A whole bag of easy, playful ideas for your little elf.','🧝')+
 `<div class="panel green"><div class="metric-line"><div><span class="eyebrow">Your elf adventures</span><div><b>${all.filter(z=>z.done).length}</b><small> / ${all.length} ideas tried</small></div></div><span style="font-size:39px">🛷</span></div><div class="progress-track"><div class="progress-fill" style="width:${all.length?all.filter(z=>z.done).length/all.length*100:0}%"></div></div></div>
 <div class="toolbar"><button class="btn primary" data-new="elf">＋ Add your idea</button><span class="tiny">12 starter ideas included</span></div>
 ${searchField('elf','Search mischievous ideas…')}${chips(['To try','Done'],ui.elfFilter,'elf')}
 <div class="list-title">Elf ideas <span>${filtered.length} shown</span></div>
 ${filtered.length?filtered.map(z=>`<article class="item ${z.done?'done':''}"><div class="item-top"><span class="item-emoji">${z.done?'⭐':'🧝'}</span><div class="item-content"><div class="item-title">${x(z.title)}</div>${z.notes?`<p class="item-sub">${x(z.notes)}</p>`:''}${z.done?'<span class="tag gold">Tried it! 🌟</span>':''}</div></div>${actionRow('elf',z.id,checkbox('elf',z.id,'done','We did it!',z.done))}</article>`).join(''):empty('🧝','No elf ideas here','Try changing the filter or add a new adventure.',null,'elf')}`;
}
function shopping(){
 const group=ui.shopGroup;const all=data.shopping.filter(z=>z.group===group);const filtered=all.filter(z=>[z.name,z.quantity,z.notes].some(v=>String(v||'').toLowerCase().includes(ui.search.shopping.toLowerCase())));
 return header('Christmas feast','Food & drink','From Christmas dinner to cosy hot chocolates.','🍪')+
 `<div class="dual-toggle"><button data-shop="Food" class="${group==='Food'?'active':''}">🍗 Food</button><button data-shop="Drinks" class="${group==='Drinks'?'active':''}">🥂 Drinks</button></div>
 <div class="stats">${stat('🛒',data.shopping.length,'Items')}${stat('✅',data.shopping.filter(z=>z.bought).length,'In basket')}${stat('📋',data.shopping.filter(z=>!z.bought).length,'Still to buy')}</div>
 <div class="toolbar"><button class="btn primary" data-new="shopping">＋ Add ${group==='Food'?'food':'drink'}</button><span class="tiny">Tap the tick when it’s bought</span></div>
 ${searchField('shopping',`Search ${group.toLowerCase()} list…`)}<div class="list-title">${group} shopping list <span>${all.filter(z=>z.bought).length} of ${all.length} bought</span></div>
 ${filtered.length?filtered.slice().sort((a,b)=>Number(a.bought)-Number(b.bought)).map(z=>`<article class="item ${z.bought?'done':''}"><div class="item-top"><span class="item-emoji">${group==='Food'?'🍪':'🥤'}</span><div class="item-content"><div class="item-title">${x(z.name)}</div><p class="item-sub">${x(z.quantity||'1')} ${z.notes?' · '+x(z.notes):''}</p></div></div>${actionRow('shopping',z.id,checkbox('shopping',z.id,'bought','Bought',z.bought))}</article>`).join(''):empty(group==='Food'?'🍗':'🥂',all.length?'No matching items':`Your ${group.toLowerCase()} list is empty`,all.length?'Try a different search.':'Add everything you need for the Christmas celebrations.',all.length?'':`Add ${group==='Food'?'food':'drink'}`,'shopping')}
 <div class="tip-card"><strong>🥧 Don’t forget the little things</strong><p>${group==='Food'?'Think gravy, crackers, stuffing, snacks and Christmas pudding.':'Think tea, hot chocolate, juice, fizz and drinks for guests.'}</p></div>`;
}
function settings(){return header('A festive little home','Settings & backup','Your lists stay on this phone, even when offline.','❄️')+
 `<div class="panel"><h3>📦 Back up your Christmas plans</h3><p class="item-sub">Share an export of all your lists with yourself. Use Restore to paste an earlier JSON backup.</p><div class="button-row"><button class="btn green" data-backup="true">Share backup</button><button class="btn secondary" data-restore="true">Restore backup</button></div></div>
 <div class="panel"><h3>🎨 Make your lists yours</h3><p class="item-sub">Add, rename or remove categories for Christmas cards and presents.</p><div class="button-row"><button class="btn cream" data-categories="cards">✎ Card categories</button><button class="btn cream" data-categories="gifts">✎ Present categories</button></div></div>
 <div class="panel red"><h3>📱 Private & offline</h3><p class="item-sub">No login, adverts or tracking. Your data is saved on your device. Uninstalling or clearing app data may erase it; make a backup first.</p></div>
 <div class="footer-note">Christmas Organiser · Version 1.0 🎄</div>`}
const pages={home,cards,calendar,presents,elf,shopping,settings};
function render(){document.getElementById('main').innerHTML=(pages[ui.page]||home)();document.querySelectorAll('.bottom-nav button').forEach(z=>z.classList.toggle('active',z.dataset.page===ui.page));}
function navigate(page){if(!pages[page])return;ui.page=page;render();window.scrollTo(0,0)}
function burst(el){if(!el)return;const r=el.getBoundingClientRect();for(let n=0;n<5;n++){const b=document.createElement('span');b.className='shimmer-burst';b.textContent=['✦','❄','✧','✨','★'][n];b.style.left=(r.left+r.width/2)+'px';b.style.top=(r.top+r.height/2)+'px';b.style.setProperty('--bx',Math.cos(n*Math.PI*2/5)*55+'px');b.style.setProperty('--by',Math.sin(n*Math.PI*2/5)*50+'px');document.body.appendChild(b);setTimeout(()=>b.remove(),950)}}
function changeMonth(n){const [y,m]=ui.calendarMonth.split('-').map(Number);const d=new Date(y,m-1+n,1);ui.calendarMonth=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;ui.selectedDate=`${ui.calendarMonth}-01`;render()}
function modal(title,body,desc=''){const layer=document.getElementById('modal-layer');layer.hidden=false;layer.innerHTML=`<section class="modal-sheet" role="dialog" aria-modal="true" aria-label="${x(title)}"><div class="modal-head"><h2>🎄 ${title}</h2><button class="close-button" data-close="true" aria-label="Close dialog">×</button></div>${desc?`<p class="modal-desc">${desc}</p>`:''}${body}</section>`;layer.querySelector('input:not([type=hidden]),textarea,select')?.focus()}
function closeModal(){const layer=document.getElementById('modal-layer');layer.hidden=true;layer.innerHTML=''}
const field=(label,name,value='',type='text',required=false,extra='')=>`<div class="field"><label for="field-${name}">${label}</label><input id="field-${name}" name="${name}" type="${type}" value="${x(value)}" ${required?'required':''} ${extra}></div>`;
const area=(label,name,value='')=>`<div class="field"><label for="field-${name}">${label}</label><textarea id="field-${name}" name="${name}" rows="2">${x(value)}</textarea></div>`;
const select=(label,name,opts,value)=>`<div class="field"><label for="field-${name}">${label}</label><select id="field-${name}" name="${name}">${opts.map(v=>`<option value="${x(v)}" ${v===value?'selected':''}>${x(v)}</option>`).join('')}</select></div>`;
function editor(type,key){
 const collection={card:'cards',event:'events',gift:'gifts',elf:'elves',shopping:'shopping'}[type];if(!collection)return;
 const old=key?data[collection].find(z=>z.id===key):null;if(key&&!old)return;
 let content='';let label={card:'card',event:'calendar event',gift:'present',elf:'elf idea',shopping:'shopping item'}[type];
 if(type==='card') content=field('Name','name',old?.name||'','text',true,'maxlength="100"')+area('Postal address (optional)','address',old?.address||'')+select('Category','category',data.categories.cards,old?.category||data.categories.cards[0])+area('Notes (optional)','notes',old?.notes||'');
 if(type==='event') content=field('Event name','title',old?.title||'','text',true,'maxlength="120"')+`<div class="field-row">${field('Date','date',old?.date||ui.selectedDate,'date',true)}${field('Time (optional)','time',old?.time||'','time')}</div>`+field('Location (optional)','location',old?.location||'')+area('Notes (optional)','notes',old?.notes||'');
 if(type==='gift') content=field('Who is it for?','recipient',old?.recipient||'','text',true,'maxlength="100"')+field('Present / gift idea','gift',old?.gift||'','text',true,'maxlength="160"')+`<div class="field-row">${field('Price (£)','price',old?.price??'0','number',true,'min="0" max="100000" step="0.01"')}${select('Category','category',data.categories.gifts,old?.category||data.categories.gifts[0])}</div>`+area('Where to buy / notes','notes',old?.notes||'');
 if(type==='elf') content=field('Idea name','title',old?.title||'','text',true,'maxlength="140"')+area('How to set it up','notes',old?.notes||'');
 if(type==='shopping') content=field('Item','name',old?.name||'','text',true,'maxlength="140"')+`<div class="field-row">${field('Quantity','quantity',old?.quantity||'1','text',false,'maxlength="50"')}${select('List','group',['Food','Drinks'],old?.group||ui.shopGroup)}</div>`+area('Notes','notes',old?.notes||'');
 modal(`${old?'Edit':'Add'} ${label}`,`<form id="editor-form" data-type="${type}" data-id="${x(key||'')}">${content}<div class="modal-actions"><button type="button" class="btn secondary" data-close="true">Cancel</button><button type="submit" class="btn primary">🎁 ${old?'Save changes':'Add to list'}</button></div></form>`,old?'A sprinkle of Christmas magic for your edits ✨':'Fill in the details below. Everything saves automatically.');
}
function val(form,key){return String(new FormData(form).get(key)||'').trim()}
function saveEditor(form){
 const type=form.dataset.type,key=form.dataset.id,collection={card:'cards',event:'events',gift:'gifts',elf:'elves',shopping:'shopping'}[type];if(!collection)return;
 const old=key?data[collection].find(z=>z.id===key):null;
 const entry={...(old||{}),id:key||id()};
 if(type==='card'){entry.name=val(form,'name');entry.address=val(form,'address');entry.category=val(form,'category');entry.notes=val(form,'notes');entry.written=Boolean(old?.written);entry.sent=Boolean(old?.sent)}
 if(type==='event'){entry.title=val(form,'title');entry.date=val(form,'date');entry.time=val(form,'time');entry.location=val(form,'location');entry.notes=val(form,'notes');if(!/^\d{4}-\d{2}-\d{2}$/.test(entry.date)){toast('Please add a valid date');return}}
 if(type==='gift'){entry.recipient=val(form,'recipient');entry.gift=val(form,'gift');entry.price=Number(val(form,'price'));if(!Number.isFinite(entry.price)||entry.price<0){toast('Enter a valid price');return}entry.category=val(form,'category');entry.notes=val(form,'notes');entry.bought=Boolean(old?.bought);entry.wrapped=Boolean(old?.wrapped)}
 if(type==='elf'){entry.title=val(form,'title');entry.notes=val(form,'notes');entry.done=Boolean(old?.done)}
 if(type==='shopping'){entry.name=val(form,'name');entry.quantity=val(form,'quantity')||'1';entry.notes=val(form,'notes');entry.group=val(form,'group');entry.bought=Boolean(old?.bought)}
 if(key){Object.assign(old,entry)}else data[collection].push(entry);
 persist();closeModal();render();toast(key?'Saved with a little sparkle ✨':'Added to your Christmas plans 🎄');
}
function categoriesModal(type){
 const cats=data.categories[type];if(!cats)return;
 const label=type==='cards'?'card':'present';
 modal(`Edit ${label} categories`,`<div class="modal-desc">Rename categories to suit your family and friends. Changes update existing lists too.</div><div id="category-list">${cats.map((c,i)=>`<div class="category-row"><span style="font-size:19px">🏷️</span><input aria-label="Category ${i+1}" value="${x(c)}" data-cat-input="${i}" maxlength="45"><button class="edit-btn" data-cat-save="${i}"><span class="pencil">✎</span> Save</button><button class="small-link" data-cat-delete="${i}" aria-label="Remove ${x(c)}">×</button></div>`).join('')}</div><hr class="separator"><form id="category-form" data-type="${type}">${field('Add a new category','category','','text',true,'maxlength="45"')}<button type="submit" class="btn green">＋ Add category</button></form><div class="modal-actions"><button class="btn secondary" data-close="true">Done</button></div>`);
 document.getElementById('modal-layer').dataset.catType=type;
}
function catSave(i){const type=document.getElementById('modal-layer').dataset.catType;const cats=data.categories[type],old=cats[i];const input=document.querySelector(`[data-cat-input="${i}"]`);if(!old||!input)return;const next=input.value.trim();if(!next){toast('Category name cannot be blank');return}if(cats.some((v,n)=>n!==i&&v.toLowerCase()===next.toLowerCase())){toast('That category already exists');return}cats[i]=next;for(const z of data[type==='cards'?'cards':'gifts'])if(z.category===old)z.category=next;const filterKey=type==='cards'?'cardsFilter':'giftsFilter';if(ui[filterKey]===old)ui[filterKey]=next;persist();render();categoriesModal(type);toast('Category renamed ✨')}
function catDelete(i){const type=document.getElementById('modal-layer').dataset.catType;const cats=data.categories[type];if(cats.length<2){toast('Keep at least one category');return}const old=cats[i];if(!old)return;const used=data[type==='cards'?'cards':'gifts'].filter(z=>z.category===old).length;confirmModal('Remove category?',`${used?`${used} list item(s) will move to ${cats.find((v,n)=>n!==i)}.`:'This category will be removed.'}`,()=>{cats.splice(i,1);for(const z of data[type==='cards'?'cards':'gifts'])if(z.category===old)z.category=cats[0];if(ui[type==='cards'?'cardsFilter':'giftsFilter']===old)ui[type==='cards'?'cardsFilter':'giftsFilter']='All';persist();render();categoriesModal(type);toast('Category removed')})}
function confirmModal(title,message,onYes){pendingConfirmation=onYes;modal(title,`<p>${x(message)}</p><div class="modal-actions"><button class="btn secondary" data-close="true">Keep it</button><button class="btn danger" data-confirm="true">Remove</button></div>`)}
let pendingConfirmation=null;
function budgetModal(){modal('Edit present budget',`<form id="budget-form">${field('Total gift budget (£)','budget',data.giftBudget,'number',true,'min="0" max="1000000" step="0.01"')}<div class="modal-actions"><button type="button" class="btn secondary" data-close="true">Cancel</button><button class="btn primary" type="submit">✦ Save budget</button></div></form>`)}
function backup(){const json=JSON.stringify({...data,exportedAt:new Date().toISOString(),app:'Christmas Organiser'},null,2);if(window.AndroidStore&&typeof AndroidStore.shareBackup==='function'){AndroidStore.shareBackup(json);toast('Choose where to send your backup');}else {navigator.clipboard?.writeText(json).then(()=>toast('Backup copied to clipboard')).catch(()=>{modal('Backup JSON',`<textarea rows="11" class="search-field" readonly>${x(json)}</textarea>`)})}}
function restoreModal(){modal('Restore a backup',`<p class="item-sub">Paste a backup you previously exported. This will replace the lists currently on this device.</p><form id="restore-form"><div class="field"><label for="restore-json">Paste backup JSON</label><textarea id="restore-json" name="restore" rows="9" required placeholder="{ ... }"></textarea></div><div class="modal-actions"><button type="button" class="btn secondary" data-close="true">Cancel</button><button type="submit" class="btn primary">Restore lists</button></div></form>`)}
function collectionFor(t){return {card:'cards',event:'events',gift:'gifts',elf:'elves',shopping:'shopping'}[t]}
function rerenderKeepSearch(kind,input){const pos=input.selectionStart;render();const next=document.querySelector(`[data-search="${kind}"]`);next?.focus();try{next?.setSelectionRange(pos,pos)}catch(e){}}
document.addEventListener('click',e=>{
 const button=e.target.closest('button,a[data-go]');if(!button)return;
 if(button.matches('.edit-btn,[data-categories]'))burst(button);
 if(button.dataset.close){closeModal();pendingConfirmation=null;return}
 if(button.dataset.confirm){if(pendingConfirmation){const run=pendingConfirmation;pendingConfirmation=null;run()}return}
 if(button.dataset.go){e.preventDefault();navigate(button.dataset.go);return}
 if(button.dataset.page){navigate(button.dataset.page);return}
 if(button.id==='settings-btn'){navigate('settings');return}
 if(button.dataset.new){editor(button.dataset.new,null);return}
 if(button.dataset.edit){editor(button.dataset.edit,button.dataset.id);return}
 if(button.dataset.categories){categoriesModal(button.dataset.categories);return}
 if(button.dataset.catSave!==undefined){catSave(Number(button.dataset.catSave));return}
 if(button.dataset.catDelete!==undefined){catDelete(Number(button.dataset.catDelete));return}
 if(button.dataset.budget){budgetModal();return}
 if(button.dataset.backup){backup();return}
 if(button.dataset.restore){restoreModal();return}
 if(button.dataset.shop){ui.shopGroup=button.dataset.shop;render();return}
 if(button.dataset.filter){ui[button.dataset.filter+'Filter']=button.dataset.value;render();return}
 if(button.dataset.day){ui.selectedDate=button.dataset.day;ui.calendarMonth=button.dataset.day.slice(0,7);render();return}
 if(button.dataset.month){changeMonth(Number(button.dataset.month));return}
 if(button.dataset.today){ui.selectedDate=todayISO();ui.calendarMonth=todayISO().slice(0,7);render();return}
 if(button.dataset.delete){const collection=collectionFor(button.dataset.delete);const z=data[collection]?.find(z=>z.id===button.dataset.id);if(!z)return;confirmModal('Remove from your list?',`Are you sure you want to delete “${z.name||z.title||z.recipient||'this item'}”?`,()=>{data[collection]=data[collection].filter(t=>t.id!==button.dataset.id);persist();closeModal();render();toast('Removed from your list')});return}
});
document.addEventListener('change',e=>{const el=e.target;if(!el.dataset.toggle)return;const collection=collectionFor(el.dataset.toggle),z=data[collection]?.find(z=>z.id===el.dataset.id);if(!z)return;z[el.dataset.field]=el.checked;persist();render();toast(el.checked?'Another festive task done! ⭐':'List updated')});
document.addEventListener('input',e=>{if(e.target.dataset.search){const kind=e.target.dataset.search;ui.search[kind]=e.target.value;rerenderKeepSearch(kind,e.target)}});
document.addEventListener('submit',e=>{
 if(!['editor-form','category-form','budget-form','restore-form'].includes(e.target.id))return;e.preventDefault();const f=e.target;
 if(f.id==='editor-form'){saveEditor(f);return}
 if(f.id==='category-form'){const type=f.dataset.type,c=val(f,'category');if(!c){toast('Please enter a category');return}if(data.categories[type].some(z=>z.toLowerCase()===c.toLowerCase())){toast('Category already exists');return}data.categories[type].push(c);persist();render();categoriesModal(type);toast('New category added ✨');return}
 if(f.id==='budget-form'){const v=Number(val(f,'budget'));if(!Number.isFinite(v)||v<0)return toast('Enter a valid budget');data.giftBudget=v;persist();closeModal();render();toast('Budget updated 🎄');return}
 if(f.id==='restore-form'){try{const obj=JSON.parse(val(f,'restore'));if(!Array.isArray(obj.cards)||!Array.isArray(obj.events)||!Array.isArray(obj.gifts)||!Array.isArray(obj.elves)||!Array.isArray(obj.shopping))throw Error('Invalid structure');confirmModal('Replace your lists?', 'This will replace the Christmas lists saved on your phone. Make sure you have a backup of anything you want to keep.',()=>{data=normalise(obj);persist();closeModal();navigate('home');toast('Backup restored 🎄')})}catch(error){toast('That backup is not valid JSON from this app')}return}
});
document.getElementById('modal-layer').addEventListener('click',e=>{if(e.target.id==='modal-layer'){closeModal();pendingConfirmation=null}});
window.appBack=function(){if(!document.getElementById('modal-layer').hidden){closeModal();return true}if(ui.page!=='home'){navigate('home');return true}return false};
render();
