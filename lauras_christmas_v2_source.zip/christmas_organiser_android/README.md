# ❄️ Laura's Christmas App — Version 2.0 (Frosty Blue)

A personal Android Christmas organiser with offline lists and opt-in online Christmas news and AI shopping research. Built in Java (Android) with a local WebView interface. No advertising or trackers.

## What's new in 2.0

- **Christmas cards:** a customisable emoji/icon per person; written/sent tracking, addresses and custom categories.
- **Daily countdown:** rotating Christmas fact and song-of-the-day *title* (no music is played).
- **Christmas calendar:** built-in annual traditions including Advent Sundays, St Nicholas Day, St Lucia Day, Christmas Eve/Day, Boxing Day, the Twelve Days of Christmas (25 Dec–5 Jan), Twelfth Night, Epiphany and the approximate winter solstice. Approximate new/full/quarter moon phases are calculated offline. Custom events have their own colour and emoji marker.
- **Present lists:** budgets, categories, bought/wrapped tracking. Hidden private lists open with **five taps on the present icon** on the Presents page. Private lists have editable names, icons, items, notes and estimates. Leave the page or switch apps to hide.
- **Shopping:** unlimited editable sections beyond Food and Drinks, with online shopping searches for individual items.
- **Hidden Elf Ideas:** tap **Laura's Christmas App** in the Home top bar **five consecutive times** to open it. Includes **24 starter ideas**, an editable December 1–24 calendar with assignable/movable idea dates, and a separate supplies/ideas checklist. Elf details never appear in the public calendar.
- **Christmas Scout:** live Google News RSS headlines fetched **when the app is opened, at most once daily**, or manually refreshed. Optional OpenAI Responses API assistant can research shopping items using web search. Requires user-provided **OpenAI API key** in Settings, internet connection and separately billed API usage; key encrypted in Android Keystore on-device. No list contents are sent to AI until the user taps Ask AI.
- **Frosty UI:** icy blue glassy panels, snowfall and sparkle effects on edit buttons.
- **Data migration:** loads the same existing Android private storage and includes extra fields in backups. Backup before updating.

## Important limitations

- An API key for ChatGPT itself is **not** provided by the ChatGPT subscription. The optional model API is a separate paid service.
- The app does **not** run unattended background daily jobs or send push notifications: it checks Christmas news when opened and shows a new daily message on that day. Network services may be unavailable or rate-limited; existing offline lists work normally.
- Date traditions are calculated for UK usage, but **moon phases and solstice dates outside 2026 are approximate**. They should not be used as an authoritative astronomical calendar. No device calendar account sync is attempted: built-in dates are shown in the app's own calendar.
- The five-tap secret sections provide concealment from casual viewing **not strong access control or encryption**. Backups include hidden details and should be kept private.
- APKs built by GitHub Actions are debug-signed and intended for personal installation. Back up lists before uninstalling, since debug signature changes may prevent installing updates over existing versions.

## GitHub APK build

1. Replace **`christmas_organiser_android_source.zip`** at the **root** of the GitHub repo with the new ZIP of exactly that name.
2. Use `.github/workflows/blank.yml` with the separate supplied GitHub Actions code; the workflow unzips `christmas_organiser_android_source.zip` and runs `gradle --no-daemon assembleDebug` in `christmas_organiser_android`.
3. When the build succeeds, download **`Lauras-Christmas-App-v2-APK`** from **Actions → successful run → Artifacts**. Extract the archive and install the `app-debug.apk` file.

The source project compiles with Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17 and Android SDK 35 (min Android 8.0). Network use requires Android's INTERNET permission. All native online connections use HTTPS.

## Project layout

- `app/src/main/assets/index.html` — user interface shell.
- `app/src/main/assets/styles.css` — icy Christmas styling and interactive elements.
- `app/src/main/assets/app.js` — state, migration, built-in dates, hidden lists, calendar, forms and news/AI panels.
- `app/src/main/java/uk/co/christmas/organiser/MainActivity.java` — private Android storage, Keystore, RSS news, user-authorised AI and browser handoff.
- `.github/workflows/android.yml` — build workflow included in the project for reference.
